@extends('admin::layouts.master')

@section('content') 
 <!-- Page Content -->
   <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h2 style="color: #EF3D25; font-style: bold;  text-align: center; margin-left: 150px "> Chào mừng bạn đến với trang quản trị Website HT-PHONE </h2> 
                   
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <div class="brand-area">
        <div class="container">
            <div class="row">
                <div class="brand-carousel" style="display: flex; margin-left: 400px;margin-top: 20px">

                    <div style="margin-right: 10px" class="brand-item"><a href="#"><img src="/img/logo/apple.jpg" alt="" /></a></div>
                    <div style="margin-right: 10px" class="brand-item"><a href="#"><img src="/img/logo/Samsung.jpg" alt="" /></a></div>
                    

                </div>
                <div class="brand-carousel" style="display: flex; margin-left: 250px; margin-top: 40px">
                <div style="margin-right: 10px" class="brand-item"><a href="#"><img src="/img/logo/xiaomi.jpg" alt="" /></a></div>
                    <div style="margin-right: 10px" class="brand-item"><a href="#"><img src="/img/logo/oppo.jpg" alt="" /></a></div>
                    <div style="margin-right: 10px" class="brand-item"><a href="#"><img src="/img/logo/vivo.jpg" alt="" /></a></div>
                </div>
            </div>
        </div>
    </div>

@section('script')

    

@stop
